package org.psjava.ds;

public interface KeyValuePair<K, V> {

	K getKey();

	V getValue();

}