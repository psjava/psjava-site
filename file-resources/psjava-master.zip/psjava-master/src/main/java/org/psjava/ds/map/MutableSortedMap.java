package org.psjava.ds.map;

public interface MutableSortedMap<K, V> extends MutableMap<K, V>, SortedMap<K, V> {
}
