package org.psjava.ds.math;

public interface Function<I, O> {
	O get(I input);
}
