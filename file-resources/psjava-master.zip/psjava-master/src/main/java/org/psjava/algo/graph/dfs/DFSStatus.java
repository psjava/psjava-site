package org.psjava.algo.graph.dfs;

enum DFSStatus {
	NOT_DISCOVERED, DISCOVERED, EXPLORED,
}