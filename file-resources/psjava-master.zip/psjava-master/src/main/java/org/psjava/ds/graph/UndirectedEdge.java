package org.psjava.ds.graph;

public interface UndirectedEdge<V> {
	V v1();

	V v2();
}