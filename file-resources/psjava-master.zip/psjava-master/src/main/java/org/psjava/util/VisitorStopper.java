package org.psjava.util;

public interface VisitorStopper {
	void stop();
}