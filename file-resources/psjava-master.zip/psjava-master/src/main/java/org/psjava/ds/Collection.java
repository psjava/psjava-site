package org.psjava.ds;

public interface Collection<T> extends Iterable<T> {
	int size();

	boolean isEmpty();
}
