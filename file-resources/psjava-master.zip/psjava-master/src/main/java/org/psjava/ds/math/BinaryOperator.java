package org.psjava.ds.math;

public interface BinaryOperator<T> {
	T calc(T a, T b);
}