package org.psjava.algo.math.numbertheory;

public interface PrimalityTester {
	boolean isPrime(long v);
}
