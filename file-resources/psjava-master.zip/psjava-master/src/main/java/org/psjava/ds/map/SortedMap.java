package org.psjava.ds.map;

public interface SortedMap<K, V> extends Map<K, V> {

}