package org.psjava.algo.math.numbertheory;

import org.psjava.ds.array.Array;

public interface PrimeNumberSieve {
	Array<Integer> calcList(int max);
}