package org.psjava.util;

public interface Factory<T> {
	T create();
}
