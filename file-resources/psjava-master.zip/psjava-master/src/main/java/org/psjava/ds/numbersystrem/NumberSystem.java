package org.psjava.ds.numbersystrem;

import java.util.Comparator;

import org.psjava.util.EqualityTester;

public interface NumberSystem<T> extends EqualityTester<T>, Comparator<T> {

}
