package org.psjava.util;

public interface FactoryByInt<T> {
	T create(int value);
}