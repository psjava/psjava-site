package org.psjava.util;

public class DoubleSquare {

	public static double calc(double a) {
		return a * a;
	}

}
