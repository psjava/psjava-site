package org.psjava.ds.graph;

public interface BipartiteGraphEdge<V> {
	V left();

	V right();
}
