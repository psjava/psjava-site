package org.psjava.ds.tree.binary.bst;

public enum RemoveResult {
	REMOVED, NOT_EXIST
}